#scientific computing library for saving, reading, and resizing images
from scipy.misc import imsave, imread, imresize
#for matrix math
import numpy as np
#for importing our keras model
import keras.models
#for regular expressions, saves time dealing with string data
import re

#system level operations (like loading files)
import sys 
#for reading operating system data
import os
#tell our app where our saved model is
sys.path.append(os.path.abspath("./model"))
from app.model.load import * 

#global vars for easy reusability
global model, graph 
#initialize these variables
model, graph = init()
import base64

from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse

from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

# Create your views here.
def index(request):
	return render(request, 'app/index.html')


def convertImage(data):
	data = data.split(',')[1]
	data = re.sub(r"\s+", '+', data)
	missing_padding = len(data) % 4
	if missing_padding:
		data += '='* (4 - missing_padding)
	with open('app/output.png', 'wb') as f:
	    f.write(base64.b64decode(data.encode()))


@csrf_exempt
def predict(request):
	#whenever the predict method is called, we're going
	#to input the user drawn character as an image into the model
	#perform inference, and return the classification
	# the raw data format of the image
	#imgData = list(request.POST.dict().keys())[1]
	imgData = list(request.POST.dict().keys())[1]
	#print(imgData)
	#encode it into a suitable format
	convertImage(imgData)
	#read the image into memory
	x = imread('app/output.png',mode='L')
	#compute a bit-wise inversion so black becomes white and vice versa
	x = np.invert(x)
	#make it the right size
	x = imresize(x,(28,28))
	#imshow(x)
	#convert to a 4D tensor to feed into our model
	x = x.reshape(1,1,28,28)
	#in our computation graph
	with graph.as_default():
		#perform the prediction
		out = model.predict(x)
		#convert the response to a string
		response = np.array_str(np.argmax(out,axis=1))[1]
		return HttpResponse(response)
